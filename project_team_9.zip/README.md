## Semester Project lecture Integration Architectures (Team-9: tldr)
---

This readme will be extended with the ongoing project.